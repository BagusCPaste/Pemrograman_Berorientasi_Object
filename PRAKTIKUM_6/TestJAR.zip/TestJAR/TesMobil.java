package PRAKTIKUM_6.TestJAR;

import PRAKTIKUM_6.TestJAR.Mobil.*;

public class TesMobil {
       public static void main(String[] args) {
              Mobil mobl = new Mobil();
              mobl.maju();
       }
       
}
